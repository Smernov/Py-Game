from random import randint
import pygame
#def1 Menu
def menu():
    window.fill(SkyGreen)
    window.blit(text_Start,btn_Start)
    window.blit(text_Exit,btn_Exit)
#
#def3 GameOver
def gameover():
    global Point, hp
    window.blit(text_Pt,btn_Pt)
    hp = 3
#
#def2 Game
def game():
    global vx,vy,Lvlv,HL,MR,MR2,hp,Tz,Point,status_game
    rocet.left += vx
    rocet.top += vy
    meteorite.left -= MR
    meteorite2.left -= MR
    meteorite3.left -= MR2
    meteorite4.left -= MR2
    #с границы
    if rocet.left < 0:
        rocet.left = 0
    if rocet.right > 1280:
        rocet.right = 1280
    #upDown
    if rocet.top < 0:
        rocet.top = 0
    if rocet.bottom > 720:
        rocet.bottom = 720
    #
    if meteorite.right <= 0:
        meteorite.left = 1280
        meteorite.top = randint(0,650)
    if meteorite2.right <= 0:
        meteorite2.left = 1280
        meteorite2.top = randint(0,650)
    if meteorite3.right <= 0:
        meteorite3.left = 1280
        meteorite3.top = randint(0,650)
    if meteorite4.right <= 0:
        meteorite4.left = 1280
        meteorite4.top = randint(0,650)
    #
    if rocet.colliderect(meteorite):
        meteorite.top = 10000
        hp -= 1
    if rocet.colliderect(meteorite2):
        meteorite2.top = 10000
        hp -= 1
    if rocet.colliderect(meteorite3):
        meteorite3.top = 10000
        hp -= 1
    if rocet.colliderect(meteorite4):
        meteorite4.top = 10000
        hp -= 1
    #Helfer
    if Helfer.right <= 0:
        Helfer.left = 1280
        Helfer.top = randint(0,650)
    if rocet.colliderect(Helfer):
        Helfer.top = 10000
        hp += 1
        Lvlv = 1
    #Selye1
    if Seyle.right <= 0:
        Seyle.left = 1280
        Seyle.top = randint(0,650)
    if rocet.colliderect(Seyle):
        Seyle.top = 10000
        Point += 1
        hp = 3
        Lvlv = 1
    #
    #hpRst
    if hp <= -5:
        status_game = "gameover"
    #
    #
    if hp <= 0:
        Lvlv = 2
    else:
        Lvlv = 1
    #Potom Fixed Helfer and Selye not hp infinity 1000000...
    if hp <= -1:
        Helfer.left -=HL
        Tz = 1
    if hp <= 0 and Tz == 1:
        Helfer.left -=HL
    if hp >= 1:
        Helfer.top = 10000
        Tz == 0
    #Fixed
    #Seyle
    if hp <= -1:
        Seyle.left -=HL
    if hp >= 1:
        Seyle.top = 10000
    #
    #Lvlv
    if Lvlv == 1:
        window.blit(Fon_image, (0,0))
        MR = 5
        MR2 = 5
        HL = randint(4,8)
    else:
        HL = 3
        MR = 25
        MR2 = 35
    #Fixed hacks menu
    window.blit(Fon_image, (0,0))
    window.blit(rocet_image, rocet)
    window.blit(Helfer_image, Helfer)
    window.blit(meteorite_image, meteorite)
    window.blit(meteorite_image, meteorite2)
    window.blit(meteorite_image, meteorite3)
    window.blit(meteorite_image, meteorite4)
    window.blit(Seyle_image, Seyle)
    window.blit(text_Pt2,btn_Pt2)
    window.blit(text_yhp,btn_yhp)

#
pygame.init()

FPS = 60 
WIDTH =1280
HEIGHT =720

white = (255,255,255)
black = (0,0,0)
SkyGreen = (102, 244, 169)
Color_Fill = (102, 244, 169)
hell_blau = (2,255,250)
status_game = "menu"

rocet_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\дляменюпуск\\Final\\GameForPython\\De.png')
rocet = rocet_image.get_rect()
Helfer_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\дляменюпуск\\Final\\GameForPython\\HelferDest.png')
Helfer = Helfer_image.get_rect()
meteorite_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\дляменюпуск\\Final\\GameForPython\\Jupiter-icon.png')
meteorite = meteorite_image.get_rect()
meteorite2_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\дляменюпуск\\Final\\GameForPython\\Jupiter-icon2.png')
meteorite2 = meteorite2_image.get_rect()
meteorite3_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\дляменюпуск\\Final\\GameForPython\\Jupiter-icon3.png')
meteorite3 = meteorite_image.get_rect()
meteorite4_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\дляменюпуск\\Final\\GameForPython\\Jupiter-icon4.png')
meteorite4 = meteorite_image.get_rect()
Fon_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\дляменюпуск\\Final\\GameForPython\\Fon.jpg')
Fon = Fon_image.get_rect()
Seyle_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\дляменюпуск\\Final\\GameForPython\\Selye.png')
Seyle = Seyle_image.get_rect()
#
rocet.center = (640,360)
#meteorite
meteorite.left = 1280
meteorite.top = randint(0,650)
meteorite2.left = 1280
meteorite2.top = randint(0,650)
meteorite3.left = 1280
meteorite3.top = randint(0,650)
meteorite4.left = 1280
meteorite4.top = randint(0,650)
#helfer
Helfer.left = meteorite.right + 55
Helfer.top = randint(0,650)
Seyle.left = meteorite.right + 75
Seyle.top = randint(0,650)
Helfer.left = meteorite2.right + 55
Helfer.top = randint(0,650)
Helfer.left = meteorite3.right + 55
Helfer.top = randint(0,650)
Helfer.left = meteorite4.right + 55
Helfer.top = randint(0,650)
#wr
vx = 0
vy = 0
Lvlv = 1
HL = randint(4,8)
MR = 5
MR2 = 5
hp = 3
Tz = 0
Point = 0
#

#text Start
Style_text = pygame.font.SysFont('Forte', 60)
text_Start = Style_text.render("Start", True, black)
btn_Start = text_Start.get_rect()
btn_Start.centerx = 640
#
#text Exit
Style_text = pygame.font.SysFont('Forte', 60)
text_Exit = Style_text.render("Exit", True, black)
btn_Exit = text_Exit.get_rect()
btn_Exit.centerx = 640
btn_Exit.top = 100
#
#text_GameoverPoin
Style_text = pygame.font.SysFont('Arial Rounded MT Bold', 60)
text_Pt = Style_text.render(f"Game Over Point:{Point} Restart", True, SkyGreen)
btn_Pt = text_Pt.get_rect()
btn_Pt.left = 45
btn_Pt.top = 70
#
#ExitMenu
Style_text = pygame.font.SysFont('impact', 60)
text_Pt2 = Style_text.render("Exit in menu", True, SkyGreen)
btn_Pt2 = text_Pt2.get_rect()
btn_Pt2.left = 0
btn_Pt2.top = 0
#
#hp
Style_text = pygame.font.SysFont('bauhaus 93', 60)
text_yhp = Style_text.render(f"you hp:{hp}", True, SkyGreen)
btn_yhp = text_yhp.get_rect()
btn_yhp.left = 500
btn_yhp.top = 0
#

window = pygame.display.set_mode((WIDTH,HEIGHT))
clock = pygame.time.Clock()

run = True 
while run:
    text_yhp = Style_text.render(f"you hp:{hp}", True, SkyGreen)
    btn_yhp = text_yhp.get_rect()
    btn_yhp.left = 500
    btn_yhp.top = 0
    #
    text_Pt = Style_text.render(f"Game Over Point:{Point} Restart", True, SkyGreen)
    btn_Pt = text_Pt.get_rect()
    btn_Pt.left = 45
    btn_Pt.top = 70

    for i in pygame.event.get():
        
        if i.type == pygame.QUIT:
            run = False
        if status_game == "game":
            #key down
            if i.type == pygame.KEYDOWN:
                if i.key == pygame.K_d:
                    vx=10
                if i.key == pygame.K_a:
                    vx=-10
                    #key up
            if i.type == pygame.KEYUP:
                if i.key == pygame.K_d:
                    vx=0
                if i.key == pygame.K_a:
                    vx=0
                    #1key down
            if i.type == pygame.KEYDOWN:
                if i.key == pygame.K_s:
                    vy=10
                if i.key == pygame.K_w:
                        vy=-10
                    #2key up
            if i.type == pygame.KEYUP:
                if i.key == pygame.K_s:
                    vy=0
                if i.key == pygame.K_w:
                    vy=0
        if status_game == "menu":
            if i.type == pygame.MOUSEBUTTONDOWN and i.button == 1:
                if btn_Start.collidepoint(i.pos):
                    status_game = "game"
                if btn_Exit.collidepoint(i.pos):
                    run = False
        if status_game == "gameover":
            if i.type == pygame.MOUSEBUTTONDOWN and i.button == 1:
                if btn_Pt.collidepoint(i.pos):
                    status_game = "menu"
                    Point = 0
                    meteorite.left = 1280
                    meteorite.top = randint(0,650)
                    meteorite2.left = 1280
                    meteorite2.top = randint(0,650)
                    meteorite3.left = 1280
                    meteorite3.top = randint(0,650)
                    meteorite4.left = 1280
                    meteorite4.top = randint(0,650)
        if status_game == "game":
            if i.type == pygame.MOUSEBUTTONDOWN and i.button == 1:
                if btn_Pt2.collidepoint(i.pos):
                    status_game = "gameover"
    #
    #ST
    if status_game == "menu":
        menu()
    if status_game == "game":
        game()
    if status_game == "gameover":
        gameover()
    #
    pygame.display.update()
    clock.tick(FPS)


pygame.quit()