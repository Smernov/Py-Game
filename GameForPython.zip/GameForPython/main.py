﻿from random import randint
import pygame
pygame.init()

FPS = 60 
WIDTH =1280
HEIGHT =720

white = (255,255,255)
black = (0,0,0)
SkyGreen = (102, 244, 169)
Color_Fill = (102, 244, 169)
hell_blau = (2,255,250)

rocet_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\DS\\De.png')
rocet = rocet_image.get_rect()
Helfer_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\DS\\HelferDest.png')
Helfer = Helfer_image.get_rect()
meteorite_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\DS\\Jupiter-icon.png')
meteorite = meteorite_image.get_rect()
meteorite2_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\DS\\Jupiter-icon2.png')
meteorite2 = meteorite2_image.get_rect()
meteorite3_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\DS\\Jupiter-icon3.png')
meteorite3 = meteorite_image.get_rect()
meteorite4_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\DS\\Jupiter-icon4.png')
meteorite4 = meteorite_image.get_rect()
Fon_image = pygame.image.load('C:\\Users\\hakid\\Desktop\\DS\\Fon.jpg')
Fon = Fon_image.get_rect()
#
rocet.center = (640,360)
#meteorite
meteorite.left = 1280
meteorite.top = randint(0,650)
meteorite2.left = 1280
meteorite2.top = randint(0,650)
meteorite3.left = 1280
meteorite3.top = randint(0,650)
meteorite4.left = 1280
meteorite4.top = randint(0,650)
#helfer
Helfer.left = meteorite.right + 55
Helfer.top = randint(0,650)
Helfer.left = meteorite2.right + 55
Helfer.top = randint(0,650)
Helfer.left = meteorite3.right + 55
Helfer.top = randint(0,650)
Helfer.left = meteorite4.right + 55
Helfer.top = randint(0,650)
vx = 0
vy = 0
Lvlv = 1
HL = randint(4,8)
MR = 5
MR2 = 5
hp = 3
Tz = 0

window = pygame.display.set_mode((WIDTH,HEIGHT))
clock = pygame.time.Clock()

run = True 
while run:

    for i in pygame.event.get():
        if i.type == pygame.QUIT:
            run = False
        #key down
        if i.type == pygame.KEYDOWN:
            if i.key == pygame.K_d:
                vx=10
            if i.key == pygame.K_a:
                vx=-10
                #key up
        if i.type == pygame.KEYUP:
            if i.key == pygame.K_d:
                vx=0
            if i.key == pygame.K_a:
                vx=0
		        #1key down
        if i.type == pygame.KEYDOWN:
            if i.key == pygame.K_s:
                vy=10
            if i.key == pygame.K_w:
                    vy=-10
		        #2key up
        if i.type == pygame.KEYUP:
            if i.key == pygame.K_s:
                vy=0
            if i.key == pygame.K_w:
                vy=0
    rocet.left += vx
    rocet.top += vy
    meteorite.left -= MR
    meteorite2.left -= MR
    meteorite3.left -= MR2
    meteorite4.left -= MR2
	#с границы
    if rocet.left < 0:
        rocet.left = 0
    if rocet.right > 1280:
        rocet.right = 1280
	#upDown
    if rocet.top < 0:
        rocet.top = 0
    if rocet.bottom > 720:
        rocet.bottom = 720
    #
    if meteorite.right <= 0:
        meteorite.left = 1280
        meteorite.top = randint(0,650)
    if meteorite2.right <= 0:
        meteorite2.left = 1280
        meteorite2.top = randint(0,650)
    if meteorite3.right <= 0:
        meteorite3.left = 1280
        meteorite3.top = randint(0,650)
    if meteorite4.right <= 0:
        meteorite4.left = 1280
        meteorite4.top = randint(0,650)
    #
    if rocet.colliderect(meteorite):
        meteorite.top = 10000
        hp -= 1
    if rocet.colliderect(meteorite2):
        meteorite2.top = 10000
        hp -= 1
    if rocet.colliderect(meteorite3):
        meteorite3.top = 10000
        hp -= 1
    if rocet.colliderect(meteorite4):
        meteorite4.top = 10000
        hp -= 1
    #Helfer
    if Helfer.right <= 0:
        Helfer.left = 1280
        Helfer.top = randint(0,650)
    if rocet.colliderect(Helfer):
        Helfer.top = 10000
        hp += 1
        Lvlv = 1
    #
    if hp <= 0:
        Lvlv = 2
    else:
        Lvlv = 1
    if hp <= -1:
        Helfer.left -=HL
        Tz = 1
    if hp <= 0 and Tz == 1:
        Helfer.left -=HL
    #Lvlv
    if Lvlv == 1:
        window.blit(Fon_image, (0,0))
        MR = 5
        MR2 = 5
        HL = randint(4,8)
    else:
        HL = 3
        MR = 25
        MR2 = 35
    window.blit(Fon_image, (0,0))
    window.blit(rocet_image, rocet)
    window.blit(Helfer_image, Helfer)
    window.blit(meteorite_image, meteorite)
    window.blit(meteorite_image, meteorite2)
    window.blit(meteorite_image, meteorite3)
    window.blit(meteorite_image, meteorite4)

    

    pygame.display.update()
    clock.tick(FPS)
